using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class WorldEvent : MonoBehaviour
{
    public GameObject meteorPrefab;
    public GameObject tornadoPrefab;

    public GameObject windPrefab1;
    public GameObject windPrefab2;
    private ParticleSystem ps1;
    private ParticleSystem ps2;
    private Walking walking;
    public GameObject player;

    public List<GameObject> supplies;
    private int i;
    private int a = 0;
    // Start is called before the first frame update
    void Start()
    {
        walking = FindObjectOfType<Walking>();

        StartCoroutine(eventWorld());
        StartCoroutine(spawnResourses());
    }

    public IEnumerator eventWorld()
    {
        yield return new WaitForSeconds(60f);

        i = Random.RandomRange(1, 6);
        Debug.Log(i);
        if (i == 1) StartCoroutine(meteorRain());
        if (i == 2) StartCoroutine(tornado());
        if (i == 3) StartCoroutine(wind());
        else StartCoroutine(eventWorld());
    }

    public IEnumerator meteorRain()
    {
        while( a < 30)
        {
            Instantiate(meteorPrefab, new Vector3(Random.RandomRange(-55, 60), 15, 0), Quaternion.identity);
            yield return new WaitForSeconds(1f);
            a += 1;
        }
        a = 0;
        yield return new WaitForSeconds(1f);

        StartCoroutine(eventWorld());
    }

    public IEnumerator tornado()
    {
        Instantiate(tornadoPrefab, new Vector3(60, 0, 0), Quaternion.identity);
        yield return new WaitForSeconds(5f);
        StartCoroutine(eventWorld());
    }

    public IEnumerator spawnResourses()
    {
        yield return new WaitForSeconds(30f);
        Debug.Log("res2");
        while (i < 6)
        {
            Instantiate(supplies[Random.RandomRange(0, supplies.Count)], new Vector3(Random.Range(-50, 50), Random.Range(-1, 1), 0), Quaternion.identity);
            i++;
        }
        i = 0;
        
        Debug.Log("res");
        StartCoroutine(spawnResourses());
    }

    public IEnumerator wind()
    {
        float startTime = Time.time;

        Vector3 position = Vector3.zero;
        Quaternion rotation = Quaternion.Euler(0f, 0f, 0f);

        bool isWindLeftToRight = Random.Range(0, 2) == 0;

        if (isWindLeftToRight)
        {
            position = new Vector3(-30f, 5f, 0f);
            rotation = Quaternion.Euler(0f, 90f, 90f);
        }
        else
        {
            position = new Vector3(30f, 5f, 0f);
            rotation = Quaternion.Euler(0f, -90f, 90f);
        }

        GameObject wind1Instance = Instantiate(windPrefab1, player.transform.position + position, rotation);
        GameObject wind2Instance = Instantiate(windPrefab2, player.transform.position + position, rotation);

        wind1Instance.transform.localScale = new Vector3(1f, 1f, 1f);
        wind2Instance.transform.localScale = new Vector3(1f, 1f, 1f);

        ps1 = wind1Instance.GetComponent<ParticleSystem>();
        ps2 = wind2Instance.GetComponent<ParticleSystem>();

        ps1.Play();
        ps2.Play();

        while (true)
        {
            if (isWindLeftToRight)
            {
                if (Input.GetAxisRaw("Horizontal") > 0f)
                {
                    walking.runSpeed = 10.5f;
                }
                else
                {
                    walking.runSpeed = 3.5f;
                }
            }
            else if (!isWindLeftToRight)
            {
                if (Input.GetAxisRaw("Horizontal") > 0f)
                {
                    walking.runSpeed = 3.5f;
                }
                else
                {
                    walking.runSpeed = 10.5f;
                }
            }

            wind1Instance.transform.position = new Vector3(player.transform.position.x + position.x, wind1Instance.transform.position.y, player.transform.position.z + position.z);
            wind2Instance.transform.position = new Vector3(player.transform.position.x + position.x, wind2Instance.transform.position.y, player.transform.position.z + position.z);

            if (Time.time - startTime >= 20f)
            {
                break;
            }

            yield return null;
        }

        ps1.Stop();
        ps2.Stop();

        yield return new WaitForSeconds(2f);

        DestroyImmediate(wind1Instance, true);
        DestroyImmediate(wind2Instance, true);

        walking.runSpeed = 7f;

        StartCoroutine(eventWorld());
    }
}
